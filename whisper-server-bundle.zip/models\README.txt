Place ggml-*.bin model files here. deploy-whisper-server.ps1 -DownloadModel will fetch one for you.
